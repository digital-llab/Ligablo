package com.llab.ligablo.database;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

import com.llab.ligablo.database.dao.etabs.AdresseDao;
import com.llab.ligablo.database.dao.etabs.EtablissementDao;
import com.llab.ligablo.database.dao.etabs.EtsTypeDao;
import com.llab.ligablo.database.dao.etabs.ExtensionDao;
import com.llab.ligablo.database.dao.users.AdminExtensionDao;
import com.llab.ligablo.database.dao.users.UserDao;
import com.llab.ligablo.models.etab.Adresse;
import com.llab.ligablo.models.etab.Etablissement;
import com.llab.ligablo.models.etab.EtsType;
import com.llab.ligablo.models.etab.Extension;
import com.llab.ligablo.models.users.AdminExtension;
import com.llab.ligablo.models.users.User;

@Database(entities = {Adresse.class, Etablissement.class, EtsType.class, Extension.class, AdminExtension.class, User.class}, version = 1, exportSchema = false)
public abstract class LigabloDatabase extends RoomDatabase {

    // --- SINGLETON --- //
    private static volatile LigabloDatabase INSTANCE;

    // --- DAO --- //


    //FROM USERS by Tadiumi
    public abstract UserDao userDao();
    public abstract AdminExtensionDao  adminExtensionDao();

    //FROM ETABS by Tadiumi
    public abstract AdresseDao adresseDao();
    public abstract EtablissementDao etablissementDao();
    public abstract EtsTypeDao etsTypeDao();
    public abstract ExtensionDao extensionDao();


    // --- INSTANCE --- //
    public static LigabloDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (LigabloDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                            LigabloDatabase.class, "MyDatabase.db")
                            .build();
                }
            }
        }

        return INSTANCE;
    }
}
